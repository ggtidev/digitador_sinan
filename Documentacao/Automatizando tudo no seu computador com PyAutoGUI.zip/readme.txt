----- AUTOMATIZANDO TUDO NO SEU COMPUTADOR COM PYAUTOGUI -----

Este é o material do curso "Automatizando tudo no seu computador com PyAutoGUI" da Asimov Academy!

Nesta pasta, há a apostila do curso, que contempla todos conceitos, códigos e imagens mostrados nas aulas. É uma material independente, ou seja, é possível estudar somente a partir desta apostila para quem preferir, mas também pode servir de guia para quem está assistindo as aulas do curso.

Bons estudos!

- Equipe Asimov

